//
//  Bridging-Header.h
//  ChatDemo
//
//  Created by MAC on 31/08/2020 .
//  Copyright © 1942 MAC.chat.demo. All rights reserved.
//

#ifndef Bridging_Header_h
#define Bridging_Header_h
#import <JSQMessagesViewController/JSQMessages.h>

#endif /* Bridging_Header_h */
