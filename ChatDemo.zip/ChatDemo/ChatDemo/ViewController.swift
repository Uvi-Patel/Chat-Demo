//
//  ViewController.swift
//  ChatDemo
//
//  Created by MAC on 31/08/2020 .
//  Copyright © 1942 MAC.chat.demo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

