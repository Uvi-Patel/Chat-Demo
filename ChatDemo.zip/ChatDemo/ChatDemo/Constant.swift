//
//  Constant.swift
//  ChatDemo
//
//  Created by MAC on 31/08/2020 .
//  Copyright © 1942 MAC.chat.demo. All rights reserved.
//

import Foundation
import Firebase
import FirebaseDatabase
struct Constants
{
    struct refs
    {
        static let databaseRoot = Database.database().reference()
        static let databaseChats = databaseRoot.child("chats")
    }
}
